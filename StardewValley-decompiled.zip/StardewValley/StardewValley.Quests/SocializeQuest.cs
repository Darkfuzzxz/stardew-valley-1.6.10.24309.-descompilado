using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Netcode;
using StardewValley.Extensions;
using StardewValley.GameData.Characters;

namespace StardewValley.Quests;

public class SocializeQuest : Quest
{
	public readonly NetStringList whoToGreet = new NetStringList();

	[XmlElement("total")]
	public readonly NetInt total = new NetInt();

	public readonly NetDescriptionElementList parts = new NetDescriptionElementList();

	[XmlElement("objective")]
	public readonly NetDescriptionElementRef objective = new NetDescriptionElementRef();

	public SocializeQuest()
	{
		questType.Value = 5;
	}

	/// <inheritdoc />
	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(whoToGreet, "whoToGreet").AddField(total, "total").AddField(parts, "parts")
			.AddField(objective, "objective");
	}

	public void loadQuestInfo()
	{
		if (whoToGreet.Count > 0)
		{
			return;
		}
		base.questTitle = Game1.content.LoadString("Strings\\StringsFromCSFiles:SocializeQuest.cs.13785");
		parts.Clear();
		parts.Add(new DescriptionElement("Strings\\StringsFromCSFiles:SocializeQuest.cs.13786", new DescriptionElement("Strings\\StringsFromCSFiles:SocializeQuest.cs." + random.Choose("13787", "13788", "13789"))));
		parts.Add("Strings\\StringsFromCSFiles:SocializeQuest.cs.13791");
		int num = 0;
		foreach (KeyValuePair<string, CharacterData> characterDatum in Game1.characterData)
		{
			string key = characterDatum.Key;
			CharacterData value = characterDatum.Value;
			if (value.IntroductionsQuest ?? (value.HomeRegion == "Town"))
			{
				num++;
				if (value.SocialTab != SocialTabBehavior.AlwaysShown || dailyQuest.Value)
				{
					whoToGreet.Add(key);
				}
			}
		}
		total.Value = num;
		objective.Value = new DescriptionElement("Strings\\StringsFromCSFiles:SocializeQuest.cs.13802", total.Value - whoToGreet.Count, total.Value);
	}

	public override void reloadDescription()
	{
		if (_questDescription == "")
		{
			loadQuestInfo();
		}
		if (parts.Count == 0 || parts == null)
		{
			return;
		}
		string text = "";
		foreach (DescriptionElement part in parts)
		{
			text += part.loadDescriptionElement();
		}
		base.questDescription = text;
	}

	public override void reloadObjective()
	{
		loadQuestInfo();
		if (objective.Value == null && whoToGreet.Count > 0)
		{
			objective.Value = new DescriptionElement("Strings\\StringsFromCSFiles:SocializeQuest.cs.13802", total.Value - whoToGreet.Count, total.Value);
		}
		if (objective.Value != null)
		{
			base.currentObjective = objective.Value.loadDescriptionElement();
		}
	}

	/// <inheritdoc />
	public override bool OnNpcSocialized(NPC npc, bool probe = false)
	{
		bool result = base.OnNpcSocialized(npc, probe);
		loadQuestInfo();
		if (whoToGreet.Contains(npc.Name))
		{
			if (!probe)
			{
				whoToGreet.Remove(npc.Name);
				Game1.dayTimeMoneyBox.moneyDial.animations.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(387, 497, 3, 8), 800f, 1, 0, Game1.dayTimeMoneyBox.position + new Vector2(228f, 244f), flicker: false, flipped: false, 1f, 0.01f, Color.White, 4f, 0.3f, 0f, 0f)
				{
					scaleChangeChange = -0.012f
				});
				Game1.dayTimeMoneyBox.pingQuest(this);
			}
			result = true;
		}
		if (whoToGreet.Count == 0 && !completed.Value)
		{
			if (!probe)
			{
				foreach (string key in Game1.player.friendshipData.Keys)
				{
					if (Game1.player.friendshipData[key].Points < 2729)
					{
						Game1.player.changeFriendship(100, Game1.getCharacterFromName(key));
					}
				}
				questComplete();
			}
			return true;
		}
		if (!probe)
		{
			objective.Value = new DescriptionElement("Strings\\StringsFromCSFiles:SocializeQuest.cs.13802", total.Value - whoToGreet.Count, total.Value);
		}
		return result;
	}
}
