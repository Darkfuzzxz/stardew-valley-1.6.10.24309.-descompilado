using System.Collections.Generic;
using StardewValley.Locations;

namespace StardewValley.Pathfinding;

/// <summary>Handles pathfinding between locations.</summary>
public static class WarpPathfindingCache
{
	/// <summary>Every possible path through location names that NPCs can take while pathfinding, indexed by the start location.</summary>
	/// <remarks>For example, <c>"BusStop": [ "BusStop", "Town", "Mountain" ]</c> means that an NPC in the bus stop can warp to town and then to the mountain.</remarks>
	private static readonly Dictionary<string, List<LocationWarpRoute>> Routes = new Dictionary<string, List<LocationWarpRoute>>();

	/// <summary>The location names which NPCs aren't allowed to warp through.</summary>
	/// <remarks>The farmhand cellars are added automatically.</remarks>
	public static readonly HashSet<string> IgnoreLocationNames = new HashSet<string> { "Backwoods", "Cellar", "Farm" };

	/// <summary>A map of warp targets to the actual location name NPCs should warp to.</summary>
	public static readonly Dictionary<string, string> OverrideTargetNames = new Dictionary<string, string> { ["BoatTunnel"] = "IslandSouth" };

	/// <summary>The locations which can only be accessed by NPCs of one gender.</summary>
	public static readonly Dictionary<string, Gender> GenderRestrictions = new Dictionary<string, Gender>
	{
		["BathHouse_MensLocker"] = Gender.Male,
		["BathHouse_WomensLocker"] = Gender.Female
	};

	/// <summary>Cache the possible pathfinding routes between game locations.</summary>
	public static void PopulateCache()
	{
		for (int i = 1; i <= Game1.netWorldState.Value.HighestPlayerLimit; i++)
		{
			IgnoreLocationNames.Add("Cellar" + i);
		}
		Routes.Clear();
		foreach (GameLocation location in Game1.locations)
		{
			if (!IgnoreLocationNames.Contains(location.NameOrUniqueName))
			{
				ExploreWarpPoints(location, new List<string>(), null);
			}
		}
	}

	/// <summary>Get a valid pathfinding route between a start and destination location.</summary>
	/// <param name="startingLocation">The name of the location the NPC is starting from.</param>
	/// <param name="endingLocation">The name of the destination location.</param>
	/// <param name="gender">The NPC's gender, used to choose gender-specific routes like the pool locker rooms.</param>
	/// <returns>If a valid route was found, returns a list of location names to transit through including the start and destination locations. For example, <c>[ "BusStop", "Town", "Mountain" ]</c> means that an NPC in the bus stop can warp to town and then to the mountain. If no valid route was found, returns null.</returns>
	public static string[] GetLocationRoute(string startingLocation, string endingLocation, Gender gender)
	{
		if (Routes.TryGetValue(startingLocation, out var value))
		{
			foreach (LocationWarpRoute item in value)
			{
				if (item.LocationNames[item.LocationNames.Length - 1] == endingLocation)
				{
					Gender? onlyGender = item.OnlyGender;
					if (!onlyGender.HasValue || item.OnlyGender == gender || gender == Gender.Undefined)
					{
						return item.LocationNames;
					}
				}
			}
		}
		return null;
	}

	/// <summary>Recursively populate the cache based on every location reachable through warps starting from this location.</summary>
	/// <param name="location">The location to start from.</param>
	/// <param name="route">The location names explored up to this point for the current route, excluding the <paramref name="location" />.</param>
	/// <param name="genderRestriction">The gender restriction for the route up to this point, if any. For example, a route which passes through the men's locker room is restricted to male NPCs.</param>
	private static void ExploreWarpPoints(GameLocation location, List<string> route, Gender? genderRestriction)
	{
		string text = location?.name.Value;
		if (text == null || location.ShouldExcludeFromNpcPathfinding() || route.Contains(text))
		{
			return;
		}
		if (GenderRestrictions.TryGetValue(text, out var value))
		{
			if (genderRestriction.HasValue && genderRestriction.Value != value)
			{
				return;
			}
			genderRestriction = value;
		}
		route.Add(text);
		if (route.Count > 1)
		{
			AddRoute(route, genderRestriction);
		}
		bool flag = location.warps.Count > 0;
		bool flag2 = location.doors.Length > 0;
		if (flag || flag2)
		{
			HashSet<string> hashSet = new HashSet<string> { text };
			if (route.Count > 1)
			{
				hashSet.Add(route[route.Count - 2]);
			}
			if (flag)
			{
				foreach (Warp warp in location.warps)
				{
					ExploreWarpPoints(warp.TargetName, route, genderRestriction, hashSet);
				}
			}
			if (flag2)
			{
				foreach (string value2 in location.doors.Values)
				{
					ExploreWarpPoints(value2, route, genderRestriction, hashSet);
				}
			}
		}
		if (route.Count > 0)
		{
			route.RemoveAt(route.Count - 1);
		}
	}

	/// <summary>Recursively populate the cache based on every location reachable through warps starting from this location.</summary>
	/// <param name="locationName">The location name to start from.</param>
	/// <param name="route">The location names explored up to this point for the current route, excluding the <paramref name="locationName" />.</param>
	/// <param name="genderRestriction">The gender restriction for the route up to this point, if any. For example, a route which passes through the men's locker room is restricted to male NPCs.</param>
	/// <param name="seenTargets">The warp target names which have already been explored from this location.</param>
	/// <returns>Returns whether any routes were added.</returns>
	private static void ExploreWarpPoints(string locationName, List<string> route, Gender? genderRestriction, HashSet<string> seenTargets)
	{
		if (OverrideTargetNames.TryGetValue(locationName, out var value))
		{
			locationName = value;
		}
		if (seenTargets.Add(locationName) && !IgnoreLocationNames.Contains(locationName) && !MineShaft.IsGeneratedLevel(locationName) && !VolcanoDungeon.IsGeneratedLevel(locationName))
		{
			ExploreWarpPoints(Game1.getLocationFromName(locationName), route, genderRestriction);
		}
	}

	/// <summary>Add a route to the <see cref="F:StardewValley.Pathfinding.WarpPathfindingCache.Routes" /> cache.</summary>
	/// <param name="route">The location names in the route.</param>
	/// <param name="onlyGender">If set, this route can only be used by NPCs of the given gender.</param>
	private static void AddRoute(List<string> route, Gender? onlyGender)
	{
		if (!Routes.TryGetValue(route[0], out var value))
		{
			value = (Routes[route[0]] = new List<LocationWarpRoute>());
		}
		value.Add(new LocationWarpRoute(route.ToArray(), onlyGender));
	}
}
