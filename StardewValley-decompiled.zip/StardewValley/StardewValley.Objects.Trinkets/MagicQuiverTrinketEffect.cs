using System;
using System.Collections.Generic;
using System.Globalization;
using Microsoft.Xna.Framework;
using StardewValley.Extensions;
using StardewValley.Monsters;
using StardewValley.Projectiles;
using StardewValley.TokenizableStrings;

namespace StardewValley.Objects.Trinkets;

/// <summary>Implements the special behavior for a <see cref="T:StardewValley.Objects.Trinkets.Trinket" /> which shoots a damaging projectile at enemies.</summary>
public class MagicQuiverTrinketEffect : TrinketEffect
{
	/// <summary>The backing field for <see cref="M:StardewValley.Objects.Trinkets.MagicQuiverTrinketEffect.GetIgnoredLocations" />.</summary>
	public static HashSet<string> CachedIgnoreLocations;

	/// <summary>The backing field for <see cref="M:StardewValley.Objects.Trinkets.MagicQuiverTrinketEffect.GetIgnoredMonsterNames" />.</summary>
	public static HashSet<string> CachedIgnoreMonsters;

	/// <summary>The pixel range at which monsters can be targeted.</summary>
	public const int Range = 500;

	/// <summary>The number of milliseconds until the trinket next shoots a projectile.</summary>
	public float ProjectileTimer;

	/// <summary>The number of milliseconds between each projectile.</summary>
	public float ProjectileDelay = 1000f;

	/// <summary>The minimum damage that can be dealt to monsters.</summary>
	public int MinDamage = 10;

	/// <summary>The minimum damage that can be dealt to monsters.</summary>
	public int MaxDamage = 10;

	/// <inheritdoc />
	public MagicQuiverTrinketEffect(Trinket trinket)
		: base(trinket)
	{
	}

	/// <inheritdoc />
	public override void Apply(Farmer farmer)
	{
		ProjectileTimer = 0f;
		base.Apply(farmer);
	}

	/// <inheritdoc />
	public override bool GenerateRandomStats(Trinket trinket)
	{
		Random random = Utility.CreateRandom(trinket.generationSeed.Value);
		if (random.NextBool(0.04))
		{
			trinket.displayNameOverrideTemplate.Value = TokenStringBuilder.LocalizedText("Strings\\1_6_Strings:PerfectMagicQuiver");
			MinDamage = 30;
			MaxDamage = 35;
			ProjectileDelay = 900f;
		}
		else if (random.NextBool(0.1))
		{
			if (random.NextBool(0.5))
			{
				trinket.displayNameOverrideTemplate.Value = TokenStringBuilder.LocalizedText("Strings\\1_6_Strings:RapidMagicQuiver");
				MinDamage = random.Next(10, 15);
				MinDamage -= 2;
				MaxDamage = MinDamage + 5;
				ProjectileDelay = 600 + random.Next(11) * 10;
			}
			else
			{
				trinket.displayNameOverrideTemplate.Value = TokenStringBuilder.LocalizedText("Strings\\1_6_Strings:HeavyMagicQuiver");
				MinDamage = random.Next(25, 41);
				MinDamage -= 2;
				MaxDamage = MinDamage + 5;
				ProjectileDelay = 1500 + random.Next(6) * 100;
			}
		}
		else
		{
			MinDamage = random.Next(15, 31);
			MinDamage -= 2;
			MaxDamage = MinDamage + 5;
			ProjectileDelay = 1100 + random.Next(11) * 100;
		}
		trinket.descriptionSubstitutionTemplates.Clear();
		trinket.descriptionSubstitutionTemplates.Add(Math.Round((double)ProjectileDelay / 1000.0, 2).ToString(CultureInfo.InvariantCulture));
		trinket.descriptionSubstitutionTemplates.Add(MinDamage.ToString());
		trinket.descriptionSubstitutionTemplates.Add(MaxDamage.ToString());
		return true;
	}

	/// <inheritdoc />
	public override void Update(Farmer farmer, GameTime time, GameLocation location)
	{
		base.Update(farmer, time, location);
		if (!Game1.shouldTimePass())
		{
			return;
		}
		ProjectileTimer += (float)time.ElapsedGameTime.TotalMilliseconds;
		if (!(ProjectileTimer >= ProjectileDelay))
		{
			return;
		}
		ProjectileTimer = 0f;
		HashSet<string> ignoredLocations = GetIgnoredLocations();
		if (!ignoredLocations.Contains(location.NameOrUniqueName) && !ignoredLocations.Contains(location.Name))
		{
			HashSet<string> ignoreMonsterNames = GetIgnoredMonsterNames();
			Monster monster = Utility.findClosestMonsterWithinRange(location, farmer.getStandingPosition(), 500, ignoreUntargetables: true, (Monster m) => !ignoreMonsterNames.Contains(m.Name));
			if (monster != null)
			{
				Vector2 velocityTowardPoint = Utility.getVelocityTowardPoint(farmer.getStandingPosition(), monster.getStandingPosition(), 2f);
				float value = (float)Math.Atan2(velocityTowardPoint.Y, velocityTowardPoint.X) + (float)Math.PI / 2f;
				BasicProjectile basicProjectile = new BasicProjectile(Game1.random.Next(MinDamage, MaxDamage + 1), 16, 0, 0, 0f, velocityTowardPoint.X, velocityTowardPoint.Y, farmer.getStandingPosition() - new Vector2(32f, 48f), null, null, null, explode: false, damagesMonsters: true, location, farmer);
				basicProjectile.IgnoreLocationCollision = true;
				basicProjectile.ignoreObjectCollisions.Value = true;
				basicProjectile.acceleration.Value = velocityTowardPoint;
				basicProjectile.maxVelocity.Value = 24f;
				basicProjectile.projectileID.Value = 14;
				basicProjectile.startingRotation.Value = value;
				basicProjectile.alpha.Value = 0.001f;
				basicProjectile.alphaChange.Value = 0.05f;
				basicProjectile.light.Value = true;
				basicProjectile.collisionSound.Value = "magic_arrow_hit";
				location.projectiles.Add(basicProjectile);
				location.playSound("magic_arrow");
			}
		}
	}

	/// <summary>Get the locations which magic quivers should ignore.</summary>
	public HashSet<string> GetIgnoredLocations()
	{
		if (CachedIgnoreLocations == null)
		{
			CachedIgnoreLocations = new HashSet<string>(ArgUtility.SplitQuoteAware(Trinket.GetTrinketData()?.CustomFields?.GetValueOrDefault("IgnoreLocations"), '/'), StringComparer.OrdinalIgnoreCase);
		}
		return CachedIgnoreLocations;
	}

	/// <summary>Get the monsters which magic quivers should ignore.</summary>
	public HashSet<string> GetIgnoredMonsterNames()
	{
		if (CachedIgnoreMonsters == null)
		{
			CachedIgnoreMonsters = new HashSet<string>(ArgUtility.SplitQuoteAware(Trinket.GetTrinketData()?.CustomFields?.GetValueOrDefault("IgnoreMonsters"), '/'), StringComparer.OrdinalIgnoreCase);
		}
		return CachedIgnoreMonsters;
	}
}
